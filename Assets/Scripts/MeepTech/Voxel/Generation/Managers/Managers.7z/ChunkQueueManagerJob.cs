﻿using MeepTech.Jobs;
using MeepTech.Voxel.Collections.Level;
using MeepTech.Voxel.Collections.Level.Managent;

namespace MeepTech.Voxel.Generation.Managers {

  /// <summary>
  /// A base job for managing chunk work queues
  /// </summary>
  public abstract class ChunkQueueManagerJob<ChunkManagerType> : QueueManagerJob2<Coordinate>
    where ChunkManagerType : IChunkResolutionManager{

    /// <summary>
    /// The level we're loading for
    /// </summary>
    public ChunkManagerType chunkManager {
      get;
      protected set;
    }

    /// <summary>
    /// Create a new job, linked to the level
    /// </summary>
    /// <param name="level"></param>
    protected ChunkQueueManagerJob(ChunkManagerType manager, int maxJobsCount = 20) : base(maxJobsCount) {
      chunkManager = manager;
    }
  }
}