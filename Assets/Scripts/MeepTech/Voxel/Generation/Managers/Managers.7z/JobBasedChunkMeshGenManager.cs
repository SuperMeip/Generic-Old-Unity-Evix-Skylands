﻿using MeepTech.Events;
using MeepTech.GamingBasics;
using MeepTech.Voxel.Collections.Level;
using MeepTech.Voxel.Generation.Mesh;
using System.Linq;
using System.Threading;

namespace MeepTech.Voxel.Generation.Managers {

  /// <summary>
  /// A chunk mesh generation manager that uses threaded jobs
  /// </summary>
  public class JobBasedChunkMeshGenManager : ChunkMeshGenerationManager {

    /// <summary>
    /// The current parent job, in charge of generating meshes for chunks in the load queue
    /// </summary>
    JGenerateChunkMeshes chunkMeshGenQueueManagerJob;

#if DEBUG
    ///// MANAGER STATS
    int totalRequestsRecieved = 0;
    internal int chunksDroppedForOurOfFocus = 0;
    internal int chunksDroppedForBeingEmpty = 0;
    internal int requestsProcessedByJobs = 0;
    internal int requestsSucessfullyProcessedByJobs = 0;
    internal int jobsDroppedMeshAlreadyExists = 0;
    internal int chunkMeshesGeneraged = 0;
    internal int generatedEmptyMeshes = 0;
#endif

    /// <summary>
    /// construct
    /// </summary>
    public JobBasedChunkMeshGenManager(ILevel  level, IChunkDataStorage chunkDataStorage, IVoxelMeshGenerator meshGenerator) : base(level, chunkDataStorage, meshGenerator) {
      chunkMeshGenQueueManagerJob = new JGenerateChunkMeshes(level, this);
    }

    /// <summary>
    /// Listen for events
    /// </summary>
    /// <param name="event"></param>
    /// <param name="origin"></param>
    public override void notifyOf(IEvent @event, IObserver origin = null) {
      switch (@event) {
        // if chunk data wasn't found in a file, lets generate it for them
        case ChunkDataLoadingFinishedEvent cfdlmcdlfe:
          chunkMeshGenQueueManagerJob.enqueue(new Coordinate[] { cfdlmcdlfe.chunkLocation });
#if DEBUG
          Interlocked.Increment(ref totalRequestsRecieved);
#endif
          break;
        default:
          return;
      }
      base.notifyOf(@event, origin);
    }

    /// <summary>
    /// Abort the manager jobs
    /// </summary>
    public override void killAll() {
      chunkMeshGenQueueManagerJob.abort();
    }

#if DEBUG
    /// <summary>
    /// Manager stats
    /// </summary>
    /// <returns></returns>
    protected override (double, string)[] provideManagerStats() {
      return new (double, string)[] {
        (totalRequestsRecieved, "Total Requests Recieved"),
        (chunksDroppedForOurOfFocus, "Chunks Droped For Going Out Of Focus"),
        (chunksDroppedForBeingEmpty, "Chunks Droped For Being Loaded But Empty"),
        (requestsProcessedByJobs, "Total Jobs Assigned"),
        (requestsSucessfullyProcessedByJobs, "Sucessfully Processed Jobs"),
        (jobsDroppedMeshAlreadyExists, "Existing Chunk Mesh; Dropped By Job"),
        (chunkMeshesGeneraged, "Total Chunk Meshes Generated"),
        (generatedEmptyMeshes, "Empty Chunk Meshes Generated"),
        (chunkMeshGenQueueManagerJob.queueCount, "Currently Queued Items")
      };
    }
#endif
  }

  /// <summary>
  /// The job manager this manager uses
  /// </summary>
  class JGenerateChunkMeshes : ChunkQueueManagerJob<JobBasedChunkMeshGenManager> {

    /// <summary>
    /// Create a new job, linked to the level
    /// </summary>
    /// <param name="level"></param>
    public JGenerateChunkMeshes(ILevel  level, JobBasedChunkMeshGenManager manager) : base(level, manager) {
      threadName = "Generate Chunk Mesh Manager";
    }

    /// <summary>
    /// get the child job given the values
    /// </summary>
    /// <param name="chunkLocation"></param>
    /// <param name="parentCancelationSources"></param>
    /// <returns></returns>
    protected override QueueTaskChildJob<Coordinate> getChildJob(Coordinate chunkLocation) {
      return new JGenerateChunkMesh(this, chunkLocation);
    }

    /// <summary>
    /// remove empty chunks that have loaded from the mesh gen queue
    /// </summary>
    /// <param name="chunkLocation"></param>
    /// <returns></returns>
    protected override bool isAValidQueueItem(Coordinate chunkLocation) {
      if (!level.chunkIsWithinLoadedBounds(chunkLocation)) {
#if DEBUG
        Interlocked.Increment(ref chunkManager.chunksDroppedForOurOfFocus);
#endif
        return false;
      }
      IVoxelChunk chunk = level.getChunk(chunkLocation);
      // the chunk can't be loaded and empty, we'll generate nothing.
      if (chunk.isLoaded && chunk.isEmpty) {
#if DEBUG
        Interlocked.Increment(ref chunkManager.chunksDroppedForBeingEmpty);
#endif
        return false;
      }

      return true;
    }

    /// <summary>
    /// Don't generate a mesh until a chunk's data is loaded
    /// </summary>
    /// <param name="queueItem"></param>
    /// <returns></returns>
    protected override bool itemIsReady(Coordinate chunkLocation) {
      if (level.chunkIsWithinMeshedBounds(chunkLocation)) {
        IVoxelChunk chunk = level.getChunk(chunkLocation, false, true, true, true);
        return chunk.isLoaded && chunk.neighborsNeighborsAreLoaded;
      }

      return false;
    }

    /// <summary>
    /// Sort the queue by distance from the focus of the level
    /// </summary>
    protected override void sortQueue() {
      queue = queue.OrderBy(o => o.distance(level.focus.chunkLocation)).ToList();
    }

    /// <summary>
    /// Child job for doing work on the chunk columns
    /// </summary>
    protected class JGenerateChunkMesh : QueueTaskChildJob<Coordinate> {

      /// <summary>
      /// The level we're loading for
      /// </summary>
      protected new JGenerateChunkMeshes jobManager;

      /// <summary>
      /// Make a new job
      /// </summary>
      /// <param name="level"></param>
      /// <param name="chunkLocation"></param>
      internal JGenerateChunkMesh(
        JGenerateChunkMeshes jobManager,
        Coordinate chunkLocation
      ) : base(chunkLocation, jobManager) {
        this.jobManager = jobManager;
        threadName = "Generate Mesh on Chunk: " + queueItem.ToString();
      }

      /// <summary>
      /// generate the chunk mesh if the level doesn't have it yet.
      /// </summary>
      protected override void doWork(Coordinate chunkLocation) {
#if DEBUG
        Interlocked.Increment(ref jobManager.chunkManager.requestsProcessedByJobs);
#endif
        if (!jobManager.chunkManager.chunkDataStorage.containsChunkMesh(chunkLocation)) {
          IMesh mesh = jobManager.chunkManager.generateMeshDataForChunk(chunkLocation);
#if DEBUG
          Interlocked.Increment(ref jobManager.chunkManager.chunkMeshesGeneraged);
#endif
          if (!mesh.isEmpty) {
            jobManager.chunkManager.chunkDataStorage.setChunkMesh(chunkLocation, mesh);
            World.EventSystem.notifyChannelOf(
              new ChunkManager.ChunkMeshGenerationFinishedEvent(chunkLocation),
              Evix.EventSystems.WorldEventSystem.Channels.TerrainGeneration
            );
          }
#if DEBUG
          else {
            Interlocked.Increment(ref jobManager.chunkManager.generatedEmptyMeshes);
          }
          Interlocked.Increment(ref jobManager.chunkManager.requestsSucessfullyProcessedByJobs);
        } else {
          Interlocked.Increment(ref jobManager.chunkManager.jobsDroppedMeshAlreadyExists);
        }
#endif
      }
    }
  }
}